<?php
return [
    'admin_password'  => 'anper2025',
    'app_name'        => 'TasadorIA',
    'app_tagline'     => 'Tasación inteligente de propiedades',
    'app_url'         => 'https://anperprimo.com/tasador',
    // Marketplace de plugins — igualar site_url al marketplace_url activa modo central
    'site_url'        => 'https://anperprimo.com/tasador',
    'marketplace_url' => 'https://anperprimo.com/tasador',
    'brand_name'      => 'TasadorIA',
    'admin_email'     => 'exeandino@gmail.com',
    'logo_url'        => '',
    'primary_color' => '#c9a84c',
    'agency_name'   => 'AnperPrimo Inmobiliaria',
    'agency_phone'  => '+54 342 000-0000',
    'agency_email'  => 'info@anperprimo.com',
    'agency_web'    => 'https://anperprimo.com',
    'db' => [
        'host' => 'localhost', 'name' => 'tasador',
        'user' => 'tasador',   'pass' => '1NBV4UVKC0KUexe', 'charset' => 'utf8mb4',
    ],
    // SMTP Brevo — configurado y activo
    'smtp' => [
        'host'      => 'smtp-relay.brevo.com',
        'port'      => 587,
        'secure'    => 'tls',
        'user'      => 'exeandino@gmail.com',
        'pass'      => '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',
        'from'      => 'noreply@anperprimo.com',
        'from_name' => 'AnperPrimo Tasador',
    ],
    'ai' => [
        'provider' => 'anthropic',
        'api_key'  => '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',
        'model'    => 'claude-opus-4-6',
        'enabled'  => true,
    ],
    // MercadoLibre Developer App — para actualización de precios de materiales
    'mercadolibre' => [
        'app_id'        => '8033613457231232',
        'client_secret' => 'vmu7MtRYYluIgbFNaNeSVqogfAjM2OUr',
    ],
    'geocoding'    => ['provider' => 'nominatim', 'google_key' => '', 'cache_days' => 30],
    'currency'     => 'USD',
    'ars_usd_rate' => 1400,
    'show_ars'     => true,
    'embed'        => ['allowed_origins' => ['*'], 'iframe_height' => '940px'],
    'report'       => ['validity_days' => 90, 'disclaimer' => 'Esta tasación es orientativa y no constituye oferta ni documento legal. Para una tasación oficial contactar a un martillero matriculado.', 'show_logo' => true],
    'algorithm'    => ['location_weight' => 40, 'size_weight' => 25, 'condition_weight' => 20, 'amenities_weight' => 10, 'ai_photo_weight' => 5],
    // API send_email: ver comentarios en tasador/api/send_email.php
    'api' => [
        'send_email' => [
            'bearer_token'            => getenv('TASADOR_SEND_EMAIL_TOKEN') ?: '',
            'smtp_test_token'         => getenv('TASADOR_SMTP_TEST_TOKEN') ?: '',
            'cors_origins'            => null,
            'rate_limit_per_hour'     => 25,
            'debug_response'          => false,
            'expose_exception_detail' => false,
        ],
    ],
];
